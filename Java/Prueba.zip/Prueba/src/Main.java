public class Main {
    public static void main( String[] args ) {
        Cola       newCola     = new Cola( 5 );
        Producer   newProducer = new Producer( newCola );
        Consumer[] newConsumer = new Consumer[ 3 ];
        
        newProducer.start();
        try {
            Thread.sleep( ( long ) ( Math.random() * 1000 ) );
        } catch ( InterruptedException e ) {
            System.out.println( "Error:" + e );
        }
        
        for ( int i = 0; i < newConsumer.length; i++ ) {
            newConsumer[ i ] = new Consumer( newCola, "Consumer-" + i );
            newConsumer[ i ].start();
            try {
                Thread.sleep( ( long ) ( Math.random() * 10 ) );
            } catch ( InterruptedException e ) {
                System.out.println( "Error:" + e );
            }
        }
    }
    
}
