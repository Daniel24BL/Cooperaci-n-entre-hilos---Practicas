public class Consumer extends Thread {
    
    private final Cola cola;
    
    public Consumer( Cola newCola, String title ) {
        super( title );
        cola = newCola;
    }
    
    @Override
    public void run() {
        int data = 0;
        while ( data < 10 ) {
            data = cola.extract();
            System.out.println(
                    this.getName() + " " + data );
            try {
                Consumer.sleep( ( long ) ( Math.random() * 10 ) );
            } catch ( InterruptedException e ) {
                System.out.println( "Error:" + e );
            }
        }
        System.out.println( "Fin" + this.getName() );
    }
    
}
