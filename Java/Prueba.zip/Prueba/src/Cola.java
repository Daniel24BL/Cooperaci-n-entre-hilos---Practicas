public class Cola {
    public int[] data;
    public int   entranceSigns, exitSigns, sizeCola, busyCola;
    
    public Cola( int sizeCola ) {
        data = new int[ sizeCola ];
        this.sizeCola = sizeCola;
        busyCola = 0;
        entranceSigns = 1;
        exitSigns = 1;
    }
    
    public synchronized void store( int size ) {
        try {
            while ( busyCola == sizeCola ) wait();
            data[ entranceSigns ] = size;
            entranceSigns = ( entranceSigns + 1 ) % sizeCola;
            busyCola++;
            notify();
        } catch ( InterruptedException e ) {
            System.out.println( "Error: " + e );
        }
    }
    
    public synchronized int extract() {
        int size = 0;
        try {
            while ( busyCola == 0 ) wait();
            size = data[ exitSigns ];
            exitSigns = ( exitSigns + 1 ) % sizeCola;
            busyCola--;
            notify();
        } catch ( InterruptedException e ) {
            System.out.println( "Error: " + e );
        }
        return size;
    }
    
}
