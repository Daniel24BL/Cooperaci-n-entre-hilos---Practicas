public class Producer extends Thread {
    private final Cola cola;
    
    public Producer( Cola newCola ) {
        super( "Producer" );
        cola = newCola;
    }
    
    @Override
    public void run() {
        int value = 0;
        while ( value <= 17 ) {
            cola.store( value );
            System.out.println( this.getName() + " " + value );
            value++;
            try {
                Producer.sleep( ( long ) ( Math.random() * 10 ) );
            } catch ( InterruptedException e ) {
                System.out.println( "Error:" + e );
            }
        }
    }
    
}
